def say_hello(a):
    a="hello"
    print("hello")
print("hello")
